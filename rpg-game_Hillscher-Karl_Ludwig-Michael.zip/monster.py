class Monster:
    def __init__(self, monsterName):
        #self.monsterIcon = '<'
        self.monsterName = monsterName

